import { useState } from 'react';
import { ArrowLeft, Calculator } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const SolarCalculator = () => {
  const navigate = useNavigate();
  const [billAmount, setBillAmount] = useState('');
  const [result, setResult] = useState(null);

  const calculateROI = (e) => {
    e.preventDefault();
    const bill = parseFloat(billAmount);
    if (isNaN(bill) || bill <= 0) return;

    // Assumptions:
    // 1 unit (kWh) = 5 Baht
    // 1 kW solar generates ~4 units/day = 120 units/month = 600 Baht/month savings
    // Cost per kW installed = ~25,000 Baht
    
    // Calculate required kW to cover 70% of the bill (assuming daytime usage)
    const targetSavings = bill * 0.7; 
    let recommendedKW = targetSavings / 600;
    
    // Round to standard sizes (3kW, 5kW, 10kW)
    if (recommendedKW <= 3) recommendedKW = 3;
    else if (recommendedKW <= 5) recommendedKW = 5;
    else if (recommendedKW <= 10) recommendedKW = 10;
    else recommendedKW = Math.ceil(recommendedKW);

    const actualSavingsPerMonth = recommendedKW * 600;
    const actualSavingsPerYear = actualSavingsPerMonth * 12;
    const estimatedCost = recommendedKW * 25000;
    const paybackYears = (estimatedCost / actualSavingsPerYear).toFixed(1);
    const requiredArea = recommendedKW * 5; // ~5 sqm per kW

    setResult({
      recommendedKW,
      actualSavingsPerMonth,
      actualSavingsPerYear,
      estimatedCost,
      paybackYears,
      requiredArea
    });
  };

  return (
    <div className="animate-fade-in">
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
        <button 
          onClick={() => navigate(-1)} 
          style={{ background: 'transparent', border: 'none', color: 'var(--text-primary)', cursor: 'pointer', padding: '0.5rem' }}
        >
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 className="text-gradient-solar" style={{ marginBottom: 0, fontSize: '2rem' }}>ประเมินจุดคุ้มทุนโซลาร์เซลล์</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Solar ROI Calculator</p>
        </div>
      </div>

      <div className="grid-2">
        <div className="equipment-card" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <h3>คำนวณจากค่าไฟปัจจุบัน</h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
            กรุณากรอกค่าไฟฟ้าเฉลี่ยต่อเดือนของคุณ ระบบจะคำนวณขนาดระบบโซลาร์เซลล์ที่เหมาะสมสำหรับการใช้งานในตอนกลางวัน (ระบบ On-Grid)
          </p>
          
          <form onSubmit={calculateROI} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div>
              <label style={{ display: 'block', marginBottom: '0.5rem', color: 'var(--text-secondary)' }}>ค่าไฟเฉลี่ยต่อเดือน (บาท)</label>
              <input 
                type="number" 
                value={billAmount}
                onChange={(e) => setBillAmount(e.target.value)}
                placeholder="เช่น 3500"
                style={{ 
                  width: '100%', 
                  padding: '1rem', 
                  borderRadius: '8px', 
                  border: '1px solid var(--border-color)', 
                  background: 'var(--bg-primary)', 
                  color: 'var(--text-primary)',
                  fontSize: '1.1rem'
                }}
                required
              />
            </div>
            
            <button 
              type="submit" 
              style={{ 
                background: 'linear-gradient(135deg, #FFB75E 0%, #ED8F03 100%)', 
                color: 'white', 
                padding: '1rem', 
                borderRadius: '8px', 
                border: 'none', 
                fontSize: '1.1rem', 
                fontWeight: 'bold', 
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.5rem'
              }}
            >
              <Calculator size={20} /> คำนวณความคุ้มค่า
            </button>
          </form>
        </div>

        {result && (
          <div className="equipment-card animate-fade-in" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1.5rem', background: 'rgba(255, 165, 0, 0.05)', border: '1px solid rgba(255, 165, 0, 0.2)' }}>
            <h3 className="text-gradient-solar">ผลการประเมิน (โดยประมาณ)</h3>
            
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
              <div>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>ขนาดที่แนะนำติดตั้ง</p>
                <p style={{ fontSize: '1.8rem', fontWeight: 'bold', color: 'var(--accent-solar)' }}>{result.recommendedKW} <span style={{ fontSize: '1rem', color: 'var(--text-primary)' }}>kW</span></p>
              </div>
              <div>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>งบประมาณเบื้องต้น</p>
                <p style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>{(result.estimatedCost).toLocaleString()} <span style={{ fontSize: '1rem' }}>บาท</span></p>
              </div>
              
              <div>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>ประหยัดไฟได้ประมาณ</p>
                <p style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#4CAF50' }}>{(result.actualSavingsPerMonth).toLocaleString()} <span style={{ fontSize: '1rem', color: 'var(--text-primary)' }}>บาท/เดือน</span></p>
              </div>
              <div>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>ระยะเวลาคืนทุน</p>
                <p style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>{result.paybackYears} <span style={{ fontSize: '1rem' }}>ปี</span></p>
              </div>

              <div>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>พื้นที่หลังคาที่ต้องใช้</p>
                <p style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>{result.requiredArea} <span style={{ fontSize: '1rem' }}>ตร.ม.</span></p>
              </div>
            </div>
            
            <div style={{ marginTop: '1rem', padding: '1rem', background: 'rgba(255,255,255,0.05)', borderRadius: '8px', fontSize: '0.85rem', color: 'var(--text-tertiary)' }}>
              * หมายเหตุ: การประเมินนี้ใช้ฐานคิดว่าคุณใช้ไฟฟ้าในตอนกลางวันประมาณ 70% ของค่าไฟทั้งหมด (ระบบ On-Grid) ราคาติดตั้งอาจเปลี่ยนแปลงตามหน้างานและยี่ห้ออุปกรณ์
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SolarCalculator;
