import { useState } from 'react';
import { ArrowLeft, GitCompare } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { equipmentData } from '../data/equipment';

const CompareTool = () => {
  const navigate = useNavigate();
  const [item1, setItem1] = useState('ac-fixed-speed');
  const [item2, setItem2] = useState('ac-inverter');

  const eq1 = equipmentData.find(e => e.id === item1);
  const eq2 = equipmentData.find(e => e.id === item2);

  return (
    <div className="animate-fade-in">
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
        <button onClick={() => navigate(-1)} style={{ background: 'transparent', border: 'none', color: 'var(--text-primary)', cursor: 'pointer', padding: '0.5rem' }}>
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 className="text-gradient-ac" style={{ marginBottom: 0, fontSize: '2rem' }}>เปรียบเทียบสเปค</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Side-by-side Compare Tool</p>
        </div>
      </div>

      <div className="equipment-card" style={{ padding: '2rem', maxWidth: '1000px', margin: '0 auto' }}>
        
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 60px 1fr', gap: '1rem', alignItems: 'center', marginBottom: '2rem' }}>
          <div>
            <select 
              value={item1} 
              onChange={(e) => setItem1(e.target.value)}
              style={{ width: '100%', padding: '1rem', borderRadius: '8px', background: 'var(--bg-tertiary)', color: 'var(--text-primary)', border: '1px solid var(--border-color)', fontSize: '1rem' }}
            >
              {equipmentData.map(eq => (
                <option key={eq.id} value={eq.id}>{eq.name}</option>
              ))}
            </select>
          </div>
          
          <div style={{ display: 'flex', justifyContent: 'center', color: 'var(--text-tertiary)' }}>
            <GitCompare size={32} />
          </div>

          <div>
            <select 
              value={item2} 
              onChange={(e) => setItem2(e.target.value)}
              style={{ width: '100%', padding: '1rem', borderRadius: '8px', background: 'var(--bg-tertiary)', color: 'var(--text-primary)', border: '1px solid var(--border-color)', fontSize: '1rem' }}
            >
              {equipmentData.map(eq => (
                <option key={eq.id} value={eq.id}>{eq.name}</option>
              ))}
            </select>
          </div>
        </div>

        {eq1 && eq2 && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
            
            {/* Item 1 */}
            <div style={{ background: 'var(--bg-tertiary)', padding: '1.5rem', borderRadius: '12px' }}>
              <h2 style={{ fontSize: '1.2rem', marginBottom: '1rem', color: 'var(--accent-primary)', minHeight: '3rem' }}>{eq1.name}</h2>
              <div style={{ marginBottom: '1.5rem' }}>
                <strong style={{ color: 'var(--text-secondary)', display: 'block', marginBottom: '0.5rem' }}>การทำงาน (Function)</strong>
                <p style={{ fontSize: '0.9rem' }}>{eq1.function}</p>
              </div>
              <div style={{ marginBottom: '1.5rem' }}>
                <strong style={{ color: 'var(--text-secondary)', display: 'block', marginBottom: '0.5rem' }}>หลักการ (Principle)</strong>
                <p style={{ fontSize: '0.9rem' }}>{eq1.principle}</p>
              </div>
              {eq1.specs.length > 0 && (
                <div style={{ marginBottom: '1.5rem' }}>
                  <strong style={{ color: 'var(--text-secondary)', display: 'block', marginBottom: '0.5rem' }}>ข้อมูลเชิงลึก</strong>
                  <ul style={{ paddingLeft: '1rem', fontSize: '0.9rem' }}>
                    {eq1.specs.map((s, i) => <li key={i} style={{ marginBottom: '0.5rem' }}><strong>{s.label}:</strong> {s.value}</li>)}
                  </ul>
                </div>
              )}
            </div>

            {/* Item 2 */}
            <div style={{ background: 'var(--bg-tertiary)', padding: '1.5rem', borderRadius: '12px' }}>
              <h2 style={{ fontSize: '1.2rem', marginBottom: '1rem', color: 'var(--accent-secondary)', minHeight: '3rem' }}>{eq2.name}</h2>
              <div style={{ marginBottom: '1.5rem' }}>
                <strong style={{ color: 'var(--text-secondary)', display: 'block', marginBottom: '0.5rem' }}>การทำงาน (Function)</strong>
                <p style={{ fontSize: '0.9rem' }}>{eq2.function}</p>
              </div>
              <div style={{ marginBottom: '1.5rem' }}>
                <strong style={{ color: 'var(--text-secondary)', display: 'block', marginBottom: '0.5rem' }}>หลักการ (Principle)</strong>
                <p style={{ fontSize: '0.9rem' }}>{eq2.principle}</p>
              </div>
              {eq2.specs.length > 0 && (
                <div style={{ marginBottom: '1.5rem' }}>
                  <strong style={{ color: 'var(--text-secondary)', display: 'block', marginBottom: '0.5rem' }}>ข้อมูลเชิงลึก</strong>
                  <ul style={{ paddingLeft: '1rem', fontSize: '0.9rem' }}>
                    {eq2.specs.map((s, i) => <li key={i} style={{ marginBottom: '0.5rem' }}><strong>{s.label}:</strong> {s.value}</li>)}
                  </ul>
                </div>
              )}
            </div>

          </div>
        )}
      </div>
    </div>
  );
};

export default CompareTool;
