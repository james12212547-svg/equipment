import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Zap, Info, Settings, AlertTriangle, Upload, Image as ImageIcon } from 'lucide-react';
import { equipmentData } from '../data/equipment';
import { saveImage, loadImage } from '../utils/db';

const EquipmentDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [localImage, setLocalImage] = useState(null);
  
  const equipment = equipmentData.find(eq => eq.id === id);

  useEffect(() => {
    if (id) {
      loadImage(id).then(savedImg => {
        if (savedImg) {
          setLocalImage(savedImg);
        } else {
          setLocalImage(null);
        }
      }).catch(err => console.error('Error loading image', err));
    }
  }, [id]);

  if (!equipment) return <div>ไม่พบข้อมูลอุปกรณ์</div>;

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const base64String = event.target.result;
        try {
          await saveImage(id, base64String);
          setLocalImage(base64String);
        } catch (error) {
          console.error('Error saving image to IndexedDB:', error);
          alert('เกิดข้อผิดพลาดในการบันทึกรูปภาพครับ พื้นที่อาจจะเต็มจริงๆ');
        }
      };
      reader.readAsDataURL(file);
    }
    // รีเซ็ตค่า input เพื่อให้สามารถเลือกไฟล์เดิมซ้ำได้ (แก้ปัญหาเปลี่ยนรูปเดิมแล้วเงียบ)
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const displayImage = localImage || equipment.image;

  const tagClass = equipment.category === 'air-conditioning' ? 'tag-ac' : 'tag-solar';

  return (
    <div className="animate-fade-in" style={{ paddingBottom: '2rem' }}>
      <button 
        onClick={() => navigate(-1)} 
        style={{ 
          background: 'var(--glass-bg)', 
          backdropFilter: 'blur(10px)',
          border: '1px solid var(--border-color)', 
          color: 'var(--text-primary)', 
          cursor: 'pointer', 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center', 
          padding: '0.75rem', 
          borderRadius: '50%',
          position: 'absolute',
          top: '2rem',
          left: '2rem',
          zIndex: 10
        }}
      >
        <ArrowLeft size={24} />
      </button>

      <div style={{ 
        width: '100%', 
        height: '40vh', 
        minHeight: '300px',
        borderRadius: 'var(--radius-lg)',
        overflow: 'hidden',
        position: 'relative',
        marginBottom: '2rem',
        background: 'var(--bg-secondary)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'var(--text-tertiary)'
      }}>
        {displayImage ? (
          <img 
            src={displayImage} 
            alt={equipment.name} 
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem' }}>
            <ImageIcon size={48} opacity={0.5} />
            <span style={{ fontSize: '1.2rem' }}>ยังไม่มีรูปภาพ</span>
          </div>
        )}

        <button 
          onClick={triggerFileInput}
          style={{
            position: 'absolute',
            bottom: '2rem',
            right: '2rem',
            background: 'var(--accent-primary)',
            color: 'white',
            border: 'none',
            padding: '0.75rem 1.5rem',
            borderRadius: 'var(--radius-full)',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            cursor: 'pointer',
            fontWeight: '600',
            boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
            zIndex: 10,
            transition: 'all 0.2s ease'
          }}
          onMouseOver={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
          onMouseOut={(e) => e.currentTarget.style.transform = 'scale(1)'}
        >
          <Upload size={18} />
          {displayImage ? 'เปลี่ยนรูปภาพ' : 'อัปโหลดรูปภาพ'}
        </button>
        <input 
          type="file" 
          ref={fileInputRef}
          onChange={handleImageUpload}
          accept="image/*"
          style={{ display: 'none' }}
        />

        <div style={{
          position: 'absolute',
          bottom: 0, left: 0, width: '100%', height: '50%',
          background: 'linear-gradient(to top, var(--bg-primary) 0%, transparent 100%)',
          pointerEvents: 'none'
        }}></div>
      </div>

      <div style={{ position: 'relative', zIndex: 2, marginTop: '-4rem', padding: '0 1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
          <span className={`tag ${tagClass}`} style={{ margin: 0 }}>{equipment.abbreviation}</span>
          <span style={{ fontSize: '1.5rem', background: 'var(--bg-secondary)', padding: '0.25rem 0.75rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
            {equipment.symbol}
          </span>
        </div>
        
        <h1 style={{ fontSize: '2.5rem', marginBottom: '0.25rem' }}>{equipment.name}</h1>
        <p style={{ color: 'var(--text-tertiary)', fontSize: '1.1rem', marginBottom: '2rem' }}>{equipment.nameEng}</p>

        <div className="grid-2">
          {/* Function & Principle */}
          <div className="glass-panel" style={{ padding: '2rem' }}>
            <h3 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--accent-primary)' }}>
              <Info size={20} /> หน้าที่และการทำงาน
            </h3>
            <div style={{ marginBottom: '1.5rem' }}>
              <h4 style={{ fontSize: '1rem', color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>เอาไว้ใช้ทำอะไร?</h4>
              <p>{equipment.function}</p>
            </div>
            <div>
              <h4 style={{ fontSize: '1rem', color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>หลักการทำงานเบื้องต้น</h4>
              <p>{equipment.principle}</p>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {/* Specs */}
            <div className="glass-panel" style={{ padding: '2rem' }}>
              <h3 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--accent-secondary)' }}>
                <Settings size={20} /> สเปคทางเทคนิค
              </h3>
              <ul style={{ listStyle: 'none' }}>
                {equipment.specs.map((spec, index) => (
                  <li key={index} style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    padding: '0.75rem 0',
                    borderBottom: index !== equipment.specs.length - 1 ? '1px solid var(--border-color)' : 'none'
                  }}>
                    <span style={{ color: 'var(--text-secondary)' }}>{spec.label}</span>
                    <span style={{ fontWeight: '500' }}>{spec.value}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Warnings */}
            <div className="glass-panel" style={{ padding: '1.5rem', borderLeft: '4px solid #ef4444' }}>
              <h4 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#ef4444', marginBottom: '0.5rem' }}>
                <AlertTriangle size={18} /> ข้อควรระวัง
              </h4>
              <p style={{ fontSize: '0.9rem', color: 'rgba(255,255,255,0.8)' }}>
                {equipment.warnings}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EquipmentDetail;
