import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import Home from './pages/Home';
import CategoryGrid from './pages/CategoryGrid';
import EquipmentDetail from './pages/EquipmentDetail';
import LearningHub from './pages/LearningHub';
import SolarCalculator from './pages/SolarCalculator';
import Quiz from './pages/Quiz';
import InteractiveSchematic from './pages/InteractiveSchematic';
import CompareTool from './pages/CompareTool';
import BtuCalculator from './pages/BtuCalculator';
import CableSizing from './pages/CableSizing';
import TroubleshootingSim from './pages/TroubleshootingSim';
import Glossary from './pages/Glossary';
import ModelViewer from './pages/ModelViewer';
import AIChatbot from './components/AIChatbot';
import Login from './pages/Login';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return sessionStorage.getItem('auth') === 'true';
  });

  const handleLogin = () => {
    sessionStorage.setItem('auth', 'true');
    setIsAuthenticated(true);
  };

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <Router>
      <div className="app-container">
        <Navigation />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/category/:categoryId" element={<CategoryGrid />} />
            <Route path="/equipment/:id" element={<EquipmentDetail />} />
            <Route path="/learning" element={<LearningHub />} />
            <Route path="/learning/calculator" element={<SolarCalculator />} />
            <Route path="/learning/quiz" element={<Quiz />} />
            <Route path="/learning/schematic" element={<InteractiveSchematic />} />
            <Route path="/learning/compare" element={<CompareTool />} />
            <Route path="/learning/btu" element={<BtuCalculator />} />
            <Route path="/learning/cable" element={<CableSizing />} />
            <Route path="/learning/simulator" element={<TroubleshootingSim />} />
            <Route path="/learning/glossary" element={<Glossary />} />
            <Route path="/learning/3d" element={<ModelViewer />} />
          </Routes>
        </main>
        <AIChatbot />
      </div>
    </Router>
  );
}

export default App;
