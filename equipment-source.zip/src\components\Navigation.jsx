import { NavLink } from 'react-router-dom';
import { Home, BookOpen } from 'lucide-react';

const Navigation = () => {
  return (
    <nav className="nav-bar">
      <NavLink 
        to="/" 
        className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
        end
      >
        <Home size={24} />
        <span>หน้าแรก</span>
      </NavLink>
      <NavLink 
        to="/learning" 
        className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
      >
        <BookOpen size={24} />
        <span>ศูนย์การเรียนรู้</span>
      </NavLink>
    </nav>
  );
};

export default Navigation;
