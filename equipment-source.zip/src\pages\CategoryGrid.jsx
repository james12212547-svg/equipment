import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { equipmentData, categories } from '../data/equipment';
import { loadImage } from '../utils/db';

const CategoryGrid = () => {
  const { categoryId } = useParams();
  const navigate = useNavigate();
  const [activeFilter, setActiveFilter] = useState('all'); // 'all', 'a-z'
  const [localImages, setLocalImages] = useState({});
  
  const category = categories.find(c => c.id === categoryId);
  let filteredEquipment = equipmentData.filter(eq => eq.category === categoryId);

  useEffect(() => {
    const fetchImages = () => {
      const categoryEquipment = equipmentData.filter(eq => eq.category === categoryId);
      
      // Load concurrently to speed up rendering and ensure React updates
      categoryEquipment.forEach(async (eq) => {
        try {
          const img = await loadImage(eq.id);
          if (img) {
            setLocalImages(prev => ({ ...prev, [eq.id]: img }));
          }
        } catch (e) {
          console.error('Error loading image for', eq.id, e);
        }
      });
    };
    if (categoryId) {
      fetchImages();
    }
  }, [categoryId]);
  
  // Search filter removed
  
  // Sort filter
  if (activeFilter === 'a-z') {
    filteredEquipment.sort((a, b) => a.name.localeCompare(b.name, 'th'));
  }

  if (!category) return <div>ไม่พบหมวดหมู่</div>;

  const tagClass = categoryId === 'air-conditioning' ? 'tag-ac' : 'tag-solar';

  return (
    <div className="animate-fade-in">
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
        <button 
          onClick={() => navigate(-1)} 
          style={{ background: 'transparent', border: 'none', color: 'var(--text-primary)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0.5rem', borderRadius: '50%' }}
        >
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 style={{ marginBottom: 0, fontSize: '2rem' }}>{category.name}</h1>
          <p style={{ color: 'var(--text-secondary)' }}>{category.nameEng}</p>
        </div>
      </div>

      <div className="filter-container">
        <button 
          className={`filter-btn ${activeFilter === 'all' ? 'active' : ''}`}
          onClick={() => setActiveFilter('all')}
        >
          ทั้งหมด
        </button>
        <button 
          className={`filter-btn ${activeFilter === 'a-z' ? 'active' : ''}`}
          onClick={() => setActiveFilter('a-z')}
        >
          เรียงตามตัวอักษร (ก-ฮ)
        </button>
      </div>

      <div className="grid-3">
        {filteredEquipment.map(eq => {
          const displayImg = localImages[eq.id] || eq.image;
          
          return (
            <Link to={`/equipment/${eq.id}`} key={eq.id} className="equipment-card">
              <div className="equipment-img-container">
                {displayImg ? (
                  <img src={displayImg} alt={eq.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : (
                  <div style={{width:'100%', height:'100%', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-tertiary)', background: 'var(--bg-tertiary)'}}>ไม่มีรูปภาพ</div>
                )}
              </div>
              <div className="equipment-info">
                <span className={`tag ${tagClass}`}>{eq.abbreviation}</span>
                <h3 style={{ fontSize: '1.1rem', marginBottom: '0.25rem' }}>{eq.name}</h3>
                <p style={{ color: 'var(--text-tertiary)', fontSize: '0.85rem' }}>{eq.nameEng}</p>
              </div>
            </Link>
          );
        })}
      </div>
      
      {filteredEquipment.length === 0 && (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-tertiary)' }}>
          <p>ไม่พบอุปกรณ์ที่ค้นหา</p>
        </div>
      )}
    </div>
  );
};

export default CategoryGrid;
